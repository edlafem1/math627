#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>

#include <mpi.h>

#include "cg.h"
#include "Ax.h"
#include "utilities.h"


#endif
